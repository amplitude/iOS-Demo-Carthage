//
//  M2SettingsViewController.h
//  m2048
//
//  Created by Danqing on 3/16/14.
//  Copyright (c) 2014 Danqing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface M2SettingsViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>

@end
